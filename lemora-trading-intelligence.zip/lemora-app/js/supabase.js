// LEMORA Trading Intelligence — Supabase Config
const SUPABASE_URL = 'https://ekkzaxulcfgcbzqmuean.supabase.co';
const SUPABASE_KEY = 'sb_publishable_O48kfu4PNhRCEI2L0Mok6A_0HgPNmWP';

// Initialize Supabase client
const { createClient } = supabase;
const db = createClient(SUPABASE_URL, SUPABASE_KEY);

// ── REPORTS ──────────────────────────────────────────────────
async function getTodayReport(date, type) {
  const { data, error } = await db
    .from('reports')
    .select('*')
    .eq('report_date', date)
    .eq('report_type', type)
    .order('created_at', { ascending: false })
    .limit(1);
  if (error) console.error('Error fetching report:', error);
  return data?.[0] || null;
}

async function getLatestReport(type) {
  const { data, error } = await db
    .from('reports')
    .select('*')
    .eq('report_type', type)
    .order('report_datetime', { ascending: false })
    .limit(1);
  if (error) console.error('Error fetching latest report:', error);
  return data?.[0] || null;
}

async function insertReport(reportData) {
  const { data, error } = await db
    .from('reports')
    .insert([reportData])
    .select();
  if (error) console.error('Error inserting report:', error);
  return data?.[0] || null;
}

// ── SETUPS ───────────────────────────────────────────────────
async function getSetupsByReport(reportId) {
  const { data, error } = await db
    .from('report_setups')
    .select('*')
    .eq('report_id', reportId)
    .order('rank', { ascending: true });
  if (error) console.error('Error fetching setups:', error);
  return data || [];
}

async function insertSetups(setups) {
  const { data, error } = await db
    .from('report_setups')
    .insert(setups)
    .select();
  if (error) console.error('Error inserting setups:', error);
  return data || [];
}

// ── EXECUTIONS ───────────────────────────────────────────────
async function getOpenExecutions() {
  const { data, error } = await db
    .from('executions')
    .select('*')
    .eq('execution_status', 'open')
    .order('entry_datetime', { ascending: false });
  if (error) console.error('Error fetching executions:', error);
  return data || [];
}

async function getAllExecutions() {
  const { data, error } = await db
    .from('executions')
    .select('*')
    .order('entry_datetime', { ascending: false });
  if (error) console.error('Error fetching executions:', error);
  return data || [];
}

async function insertExecution(executionData) {
  const { data, error } = await db
    .from('executions')
    .insert([executionData])
    .select();
  if (error) console.error('Error inserting execution:', error);
  return data?.[0] || null;
}

async function updateExecution(executionId, updates) {
  const { data, error } = await db
    .from('executions')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('execution_id', executionId)
    .select();
  if (error) console.error('Error updating execution:', error);
  return data?.[0] || null;
}

// ── NEWS ─────────────────────────────────────────────────────
async function getNewsByReport(reportId) {
  const { data, error } = await db
    .from('news_items')
    .select('*')
    .eq('report_id', reportId)
    .order('rank', { ascending: true });
  if (error) console.error('Error fetching news:', error);
  return data || [];
}

// ── WATCHLIST ────────────────────────────────────────────────
async function getWatchlistByReport(reportId) {
  const { data, error } = await db
    .from('watchlist_items')
    .select('*')
    .eq('report_id', reportId)
    .order('rank', { ascending: true });
  if (error) console.error('Error fetching watchlist:', error);
  return data || [];
}

// ── TRADING DAYS ─────────────────────────────────────────────
async function getTradingDays(limit = 30) {
  const { data, error } = await db
    .from('trading_days')
    .select('*')
    .order('trading_date', { ascending: false })
    .limit(limit);
  if (error) console.error('Error fetching trading days:', error);
  return data || [];
}

async function upsertTradingDay(dayData) {
  const { data, error } = await db
    .from('trading_days')
    .upsert([dayData], { onConflict: 'trading_date' })
    .select();
  if (error) console.error('Error upserting trading day:', error);
  return data?.[0] || null;
}

// ── PRIORITY REFERENCE ───────────────────────────────────────
async function getPriorityRefByReport(reportId) {
  const { data, error } = await db
    .from('priority_reference_snapshot')
    .select('*')
    .eq('report_id', reportId)
    .order('ticker', { ascending: true });
  if (error) console.error('Error fetching priority ref:', error);
  return data || [];
}

// Export all functions
window.LEMORA_DB = {
  getTodayReport, getLatestReport, insertReport,
  getSetupsByReport, insertSetups,
  getOpenExecutions, getAllExecutions, insertExecution, updateExecution,
  getNewsByReport, getWatchlistByReport,
  getTradingDays, upsertTradingDay,
  getPriorityRefByReport,
  db
};
