// LEMORA Trading Intelligence — Main Logic
// Loads data from Supabase and renders the dashboard

const TODAY = new Date().toISOString().split('T')[0];
let currentMode = 'daily';
let currentReport = null;
let currentSetups = [];
let openExecutions = [];

// ── INIT ─────────────────────────────────────────────────────
async function initDashboard() {
  updateDate();
  setInterval(updateDate, 60000);
  await loadMode('daily');
  await loadOpenPositions();
  await loadHistory();
  await loadTradingDays();
}

function updateDate() {
  const now = new Date();
  const days = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  const str = `${days[now.getDay()]} ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()} · ${now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})} CST`;
  const el = document.getElementById('topbar-date');
  if (el) el.textContent = str;
}

// ── LOAD MODE ────────────────────────────────────────────────
async function loadMode(mode) {
  currentMode = mode;
  document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
  const btn = document.querySelector(`.mode-btn[data-mode="${mode}"]`);
  if (btn) btn.classList.add('active');
  document.querySelectorAll('.mode-panel').forEach(p => p.classList.remove('visible'));
  const panel = document.getElementById('panel-' + mode);
  if (panel) panel.classList.add('visible');

  // Load report from Supabase
  showLoading(true);
  const report = await LEMORA_DB.getTodayReport(TODAY, mode);
  currentReport = report;

  if (report) {
    await renderReport(report, mode);
  } else {
    renderNoReport(mode);
  }
  showLoading(false);
}

// ── RENDER REPORT ────────────────────────────────────────────
async function renderReport(report, mode) {
  // Update regime badge
  updateRegimeBadge(report.regime_label, report.confidence_pct);

  // Update market prices if available
  if (report.spy_price) document.getElementById('p-spy').value = report.spy_price;
  if (report.qqq_price) document.getElementById('p-qqq').value = report.qqq_price;
  if (report.vix_level) document.getElementById('p-vix').value = report.vix_level;
  if (report.nq_price) document.getElementById('p-nq').value = report.nq_price;

  // Load setups
  const setups = await LEMORA_DB.getSetupsByReport(report.report_id);
  currentSetups = setups;

  const swingSetups = setups.filter(s => s.setup_type === 'swing');
  const tacticalSetups = setups.filter(s => s.setup_type === 'tactical');

  renderSwingTable(swingSetups);
  renderTacticalTable(tacticalSetups);

  // Load news
  const news = await LEMORA_DB.getNewsByReport(report.report_id);
  renderNews(news);

  // Load watchlist
  const watchlist = await LEMORA_DB.getWatchlistByReport(report.report_id);
  renderWatchlist(watchlist);

  // Update portfolio summary
  updatePortfolioSummary(report);
}

function renderNoReport(mode) {
  const labels = {
    pre_market: 'Pre-Market',
    daily: 'Daily',
    intraday: 'Intraday',
    post_close: 'Post-Close'
  };
  const tbody = document.getElementById('swing-tbody');
  if (tbody) {
    tbody.innerHTML = `<tr><td colspan="12" style="text-align:center;padding:30px;font-family:var(--mono);font-size:12px;color:var(--text-dim);">
      Sin reporte ${labels[mode] || mode} para hoy. Corre Jacky y manda el PDF a Claude para generar el reporte.
    </td></tr>`;
  }
}

// ── RENDER SWING TABLE ───────────────────────────────────────
function renderSwingTable(setups) {
  const tbody = document.getElementById('swing-tbody');
  if (!tbody) return;

  if (!setups.length) {
    tbody.innerHTML = `<tr><td colspan="12" style="text-align:center;padding:20px;font-family:var(--mono);font-size:11px;color:var(--text-dim);">Sin setups swing para hoy.</td></tr>`;
    return;
  }

  tbody.innerHTML = setups.map((s, i) => {
    const dirClass = s.direction === 'CALL' ? 'badge-enter' : s.direction === 'PUT' ? 'badge-skip' : 'badge-wait';
    const actionClass = s.action === 'ENTRA' ? 'badge-enter' : s.action === 'ESPERA' ? 'badge-wait' : s.action === 'SKIP' ? 'badge-skip' : 'badge-optional';
    const actionLabel = s.action === 'ENTRA' ? '✅ ENTRA' : s.action === 'ESPERA' ? '⚠ ESPERA' : s.action === 'SKIP' ? '⛔ SKIP' : '◎ OPCIONAL';
    const isOpen = openExecutions.find(e => e.ticker === s.ticker);

    return `<tr>
      <td style="text-align:center;">
        <input type="checkbox" class="exec-check" ${isOpen ? 'checked' : ''} 
          onchange="toggleExecution('${s.setup_id}','${s.ticker}','${s.direction}','${s.primary_structure}','${s.stop_stock}',this)"
          ${s.action === 'SKIP' ? 'disabled' : ''}>
      </td>
      <td style="color:var(--text-dim);font-size:11px;">${String(i+1).padStart(2,'0')}</td>
      <td>
        <div class="ticker">${s.ticker}</div>
        <div class="ticker-price">${s.current_price ? '$'+s.current_price : '—'}</div>
      </td>
      <td><span class="badge ${actionClass}">${actionLabel}</span></td>
      <td><span class="badge ${dirClass}" style="min-width:52px;justify-content:center;">${s.direction || '—'}</span></td>
      <td><span class="structure-sw">${s.primary_structure || '—'}</span></td>
      <td><div class="entry-val">${(s.entry_trigger || s.entry_plan || '—').replace(/\n/g,'<br>')}</div></td>
      <td><div class="stop-val">${s.stop_stock ? '$'+s.stop_stock : '—'}</div></td>
      <td><div class="target-val">${s.exit_1 || '—'}</div></td>
      <td><div class="target-val">${s.exit_2 || '—'}</div></td>
      <td><div class="contracts">1x</div></td>
      <td>${s.webull_alert ? `<div class="webull-alert">⚠ ${s.webull_alert}</div>` : '—'}</td>
    </tr>`;
  }).join('');
}

// ── RENDER TACTICAL TABLE ────────────────────────────────────
function renderTacticalTable(setups) {
  const tbody = document.getElementById('tactical-tbody');
  if (!tbody) return;

  if (!setups.length) {
    tbody.innerHTML = `<tr><td colspan="12" style="text-align:center;padding:20px;font-family:var(--mono);font-size:11px;color:var(--text-dim);">Sin setups tácticos para hoy.</td></tr>`;
    return;
  }

  tbody.innerHTML = setups.map((s, i) => {
    const dirClass = s.direction === 'CALL' ? 'badge-enter' : 'badge-skip';
    const actionClass = s.action === 'ENTRA' ? 'badge-tactical' : s.action === 'ESPERA' ? 'badge-wait' : 'badge-skip';
    const actionLabel = s.action === 'ENTRA' ? '⚡ TÁCTICO' : s.action === 'ESPERA' ? '⚠ ESPERA' : '⛔ SKIP';

    return `<tr>
      <td style="text-align:center;">
        <input type="checkbox" style="accent-color:var(--purple);"
          onchange="toggleExecution('${s.setup_id}','${s.ticker}','${s.direction}','${s.primary_structure}','${s.stop_stock}',this)">
      </td>
      <td style="color:var(--text-dim);font-size:11px;">${String(i+1).padStart(2,'0')}</td>
      <td>
        <div class="ticker">${s.ticker}</div>
        <div class="ticker-price">${s.current_price ? '$'+s.current_price : '—'}</div>
      </td>
      <td><span class="badge ${actionClass}">${actionLabel}</span></td>
      <td><span class="badge ${dirClass}" style="min-width:52px;justify-content:center;">${s.direction || '—'}</span></td>
      <td><span class="structure-tc">${s.primary_structure || '—'}</span></td>
      <td><div class="entry-val">${(s.entry_trigger || '—').replace(/\n/g,'<br>')}</div></td>
      <td><div class="stop-val">${s.stop_stock ? '$'+s.stop_stock : '—'}</div></td>
      <td><div class="target-val">${s.exit_1 || '—'}</div></td>
      <td style="font-family:var(--mono);font-size:12px;color:var(--purple);font-weight:700;">${s.preferred_dte_bucket || '3d'}</td>
      <td><div class="contracts">1x</div></td>
      <td>${s.webull_alert ? `<div class="webull-alert" style="border-color:var(--purple);color:var(--purple);">⚠ ${s.webull_alert}</div>` : '—'}</td>
    </tr>`;
  }).join('');
}

// ── RENDER NEWS ──────────────────────────────────────────────
function renderNews(newsItems) {
  const container = document.getElementById('news-panel');
  if (!container) return;

  if (!newsItems.length) {
    container.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--text-dim);padding:20px;text-align:center;">Sin noticias para este reporte.</div>`;
    return;
  }

  container.innerHTML = newsItems.map(n => `
    <div class="news-item">
      <div class="news-rank">${String(n.rank || 0).padStart(2,'0')}</div>
      <div class="news-content">
        <div class="news-headline">
          ${n.link_reference
            ? `<a href="${n.link_reference}" target="_blank" rel="noopener">${n.headline} ↗</a>`
            : n.headline}
        </div>
        <div class="news-meta">
          <span class="news-source">${n.source || ''}</span>
          <span class="news-impact impact-${(n.market_impact||'low').toLowerCase()}">${n.market_impact || ''}</span>
          <span class="news-tickers">${n.affected_tickers_sectors || ''}</span>
          <span class="news-impl">→ ${n.trade_implication || ''}</span>
        </div>
      </div>
    </div>`).join('');
}

// ── RENDER WATCHLIST ─────────────────────────────────────────
function renderWatchlist(items) {
  const tbody = document.getElementById('watchlist-tbody');
  if (!tbody) return;
  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="3" style="text-align:center;color:var(--text-dim);padding:16px;font-size:11px;">Sin watchlist para este reporte.</td></tr>`;
    return;
  }
  tbody.innerHTML = items.map(w => `
    <tr>
      <td><span class="ticker" style="font-size:13px;">${w.ticker}</span></td>
      <td><span class="entry-val">${w.trigger_to_watch || '—'}</span></td>
      <td style="font-size:11px;color:var(--text-dim);">${w.reason || '—'}</td>
    </tr>`).join('');
}

// ── EXECUTIONS ───────────────────────────────────────────────
async function toggleExecution(setupId, ticker, direction, structure, stopStock, cb) {
  if (cb.checked) {
    const exec = await LEMORA_DB.insertExecution({
      report_id: currentReport?.report_id,
      setup_id: setupId,
      ticker,
      executed: true,
      execution_status: 'open',
      direction,
      structure,
      stop_stock_price: parseFloat(stopStock) || null,
      contracts: 1,
      win_loss: 'OPEN',
      entry_datetime: new Date().toISOString()
    });
    if (exec) {
      showToast(`${ticker} agregado a posiciones ✅`);
      await loadOpenPositions();
      await renderEntries();
    }
  } else {
    // Remove open execution
    const existing = openExecutions.find(e => e.ticker === ticker && e.execution_status === 'open');
    if (existing) {
      await LEMORA_DB.updateExecution(existing.execution_id, { execution_status: 'cancelled' });
      showToast(`${ticker} removido`);
      await loadOpenPositions();
      await renderEntries();
    }
  }
  updatePortfolioCount();
}

async function loadOpenPositions() {
  openExecutions = await LEMORA_DB.getOpenExecutions();
  updatePortfolioCount();
  await renderIntraday();
}

function updatePortfolioCount() {
  const el = document.getElementById('active-trades');
  if (el) el.textContent = openExecutions.length;
  const el2 = document.getElementById('open-positions');
  if (el2) el2.textContent = openExecutions.length;
}

async function renderEntries() {
  const container = document.getElementById('entries-container');
  if (!container) return;
  const all = await LEMORA_DB.getAllExecutions();

  if (!all.length) {
    container.innerHTML = `<div style="font-family:var(--mono);font-size:12px;color:var(--text-dim);text-align:center;padding:40px;">Sin entradas. Selecciona trades en la tabla de acción.</div>`;
    return;
  }

  const TYPE_LABELS = { swing: '📈 Swing', tactical: '⚡ Táctico' };

  container.innerHTML = all.map(e => {
    const sc = e.execution_status === 'open' ? 'var(--yellow)'
      : e.win_loss === 'WIN' ? 'var(--green)'
      : e.win_loss === 'EVEN' ? 'var(--blue)' : 'var(--red)';
    const sl = e.execution_status === 'open' ? '🟡 ABIERTO'
      : e.win_loss === 'WIN' ? '✅ GANANCIA'
      : e.win_loss === 'EVEN' ? '➡ BREAK EVEN' : '❌ PÉRDIDA';

    return `<div class="journal-entry" style="border-left:3px solid ${e.setup_type === 'tactical' ? 'var(--purple)' : 'var(--green)'};">
      <div class="je-header">
        <div class="je-ticker">${e.ticker}</div>
        <span class="badge" style="background:${sc}22;border:1px solid ${sc};color:${sc};">${sl}</span>
        <span class="badge" style="background:var(--blue-dim);border:1px solid var(--blue);color:var(--blue);">${TYPE_LABELS[e.setup_type] || 'Swing'}</span>
        <div class="je-time">${e.entry_datetime ? new Date(e.entry_datetime).toLocaleDateString() : '—'}</div>
        <div class="je-actions">
          ${e.execution_status === 'open' ? `<button class="btn-close-trade" onclick="openCloseModal('${e.execution_id}','${e.ticker}')">🔒 Cerrar</button>` : ''}
        </div>
      </div>
      <div class="je-grid-4">
        <div><div class="je-label">Estructura</div><div class="je-value" style="font-size:12px;">${e.structure || '—'}</div></div>
        <div><div class="je-label">Dirección</div><div class="je-value">${e.direction || '—'}</div></div>
        <div><div class="je-label">Stop Stock</div><div class="je-value" style="color:var(--red);">$${e.stop_stock_price || '—'}</div></div>
        <div><div class="je-label">Contratos</div><div class="je-value" style="color:var(--blue);">${e.contracts || 1}</div></div>
        ${e.realized_pnl ? `<div><div class="je-label">P&L</div><div class="je-value" style="color:${sc};">$${e.realized_pnl}</div></div>` : ''}
        ${e.pnl_pct ? `<div><div class="je-label">ROI</div><div class="je-value" style="color:${sc};">${e.pnl_pct}%</div></div>` : ''}
      </div>
    </div>`;
  }).join('');
}

async function renderIntraday() {
  const tbody = document.getElementById('intraday-tbody');
  if (!tbody) return;

  if (!openExecutions.length) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:var(--text-dim);font-family:var(--mono);font-size:11px;padding:20px;">Sin posiciones abiertas.</td></tr>`;
    return;
  }

  tbody.innerHTML = openExecutions.map(e => `
    <tr>
      <td><div class="ticker">${e.ticker}</div></td>
      <td style="font-size:10px;color:var(--text-dim);">${e.setup_type === 'tactical' ? '⚡ Táctico' : '📈 Swing'}</td>
      <td><span style="font-family:var(--mono);font-size:12px;color:var(--text-mid);">—</span></td>
      <td><span style="font-family:var(--mono);font-size:12px;color:var(--text-mid);">—</span></td>
      <td><span class="badge badge-valid">VÁLIDO</span></td>
      <td><span class="badge badge-wait">PENDIENTE</span></td>
      <td><span class="badge badge-valid">OK</span></td>
      <td><span class="badge badge-hold">HOLD</span></td>
      <td style="font-size:11px;color:var(--text-dim);">Revisar en Webull · Stop: $${e.stop_stock_price || '—'}</td>
    </tr>`).join('');
}

// ── CLOSE TRADE MODAL ────────────────────────────────────────
function openCloseModal(executionId, ticker) {
  document.getElementById('close-entry-id').value = executionId;
  document.getElementById('close-modal').classList.add('open');
  document.getElementById('close-exit').value = '';
  document.getElementById('close-modal-title').textContent = `🔒 Cerrar Trade — ${ticker}`;
}

async function confirmCloseEntry() {
  const id = document.getElementById('close-entry-id').value;
  const exit = parseFloat(document.getElementById('close-exit').value);
  const result = document.getElementById('close-result').value;
  if (!exit) { showToast('⚠ Ingresa precio de salida'); return; }

  const exec = openExecutions.find(e => e.execution_id === id);
  const entryFill = parseFloat(exec?.entry_fill) || 0;
  const contracts = parseInt(exec?.contracts) || 1;
  const pnl = entryFill > 0 ? ((exit - entryFill) * 100 * contracts) : 0;
  const pnlPct = entryFill > 0 ? (((exit - entryFill) / entryFill) * 100) : 0;

  await LEMORA_DB.updateExecution(id, {
    execution_status: result,
    final_exit_fill: exit,
    final_exit_datetime: new Date().toISOString(),
    realized_pnl: pnl.toFixed(2),
    pnl_pct: pnlPct.toFixed(1),
    win_loss: result === 'closed_win' ? 'WIN' : result === 'closed_even' ? 'EVEN' : 'LOSS'
  });

  closeModal('close-modal');
  showToast(`Trade cerrado ${result === 'closed_win' ? '✅' : '❌'} ${pnlPct.toFixed(1)}%`);
  await loadOpenPositions();
  await renderEntries();
  await loadHistory();
}

// ── HISTORY ──────────────────────────────────────────────────
async function loadHistory() {
  const all = await LEMORA_DB.getAllExecutions();
  const closed = all.filter(e => e.execution_status !== 'open' && e.execution_status !== 'cancelled');
  const tbody = document.getElementById('history-tbody');
  if (!tbody) return;

  if (!closed.length) {
    tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;color:var(--text-dim);font-size:11px;padding:20px;">Historial vacío</td></tr>`;
    return;
  }

  tbody.innerHTML = closed.map(h => {
    const c = h.win_loss === 'WIN' ? 'var(--green)' : h.win_loss === 'EVEN' ? 'var(--yellow)' : 'var(--red)';
    return `<tr>
      <td style="font-size:11px;color:var(--text-dim);">${h.entry_datetime ? new Date(h.entry_datetime).toLocaleDateString() : '—'}</td>
      <td><span class="ticker" style="font-size:13px;">${h.ticker}</span></td>
      <td style="font-size:10px;color:var(--text-dim);">${h.direction || '—'}</td>
      <td style="font-size:11px;">${h.preferred_dte_bucket || '—'}</td>
      <td style="font-size:11px;">${h.structure || '—'}</td>
      <td style="font-size:11px;color:var(--text-mid);">$${h.entry_fill || '—'}</td>
      <td style="font-size:11px;">$${h.final_exit_fill || '—'}</td>
      <td style="font-size:11px;color:var(--text-dim);">$${h.capital_used || '—'}</td>
      <td style="font-size:12px;font-weight:700;color:${c};">$${h.realized_pnl || '—'}</td>
      <td style="font-size:12px;color:${c};">${h.pnl_pct || '—'}%</td>
      <td><span class="badge" style="background:${c}22;border:1px solid ${c};color:${c};font-size:10px;">${h.win_loss || '—'}</span></td>
    </tr>`;
  }).join('');
}

// ── TRADING DAYS HISTORY ─────────────────────────────────────
async function loadTradingDays() {
  const days = await LEMORA_DB.getTradingDays(30);
  const container = document.getElementById('days-history-container');
  if (!container) return;

  if (!days.length) {
    container.innerHTML = `<div style="font-family:var(--mono);font-size:12px;color:var(--text-dim);text-align:center;padding:40px;">Sin días archivados aún.</div>`;
    return;
  }

  container.innerHTML = days.map(day => {
    const pnlColor = (day.total_pnl || 0) >= 0 ? 'var(--green)' : 'var(--red)';
    return `<div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:16px;margin-bottom:12px;">
      <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
        <div style="font-family:var(--mono);font-size:14px;font-weight:700;">${day.trading_date}</div>
        <div style="font-family:var(--mono);font-size:12px;color:var(--green);">✅ ${day.winning_trades || 0} WIN</div>
        <div style="font-family:var(--mono);font-size:12px;color:var(--red);">❌ ${day.losing_trades || 0} LOSS</div>
        <div style="font-family:var(--mono);font-size:14px;font-weight:700;color:${pnlColor};">P&L: $${day.total_pnl || 0}</div>
        <div style="font-family:var(--mono);font-size:11px;color:var(--text-dim);">${day.regime || ''}</div>
      </div>
      ${day.notes ? `<div style="font-family:var(--mono);font-size:11px;color:var(--text-dim);margin-top:8px;">📝 ${day.notes}</div>` : ''}
    </div>`;
  }).join('');
}

// ── REGIME BADGE ─────────────────────────────────────────────
function updateRegimeBadge(regime, confidence) {
  const badge = document.getElementById('regime-badge-main');
  if (!badge) return;
  const label = `${regime || 'Selective Risk-On'} · ${confidence || 62}%`;
  badge.childNodes[0].textContent = label + ' ℹ';

  // Color by regime
  if (regime?.includes('Risk-Off')) {
    badge.style.borderColor = 'var(--red)';
    badge.style.background = 'var(--red-dim)';
    badge.style.color = 'var(--red)';
  } else if (regime?.includes('Fragile') || regime?.includes('Cautious')) {
    badge.style.borderColor = 'var(--orange)';
    badge.style.background = 'rgba(255,109,0,.1)';
    badge.style.color = 'var(--orange)';
  } else if (regime?.includes('Broad')) {
    badge.style.borderColor = 'var(--green)';
    badge.style.background = 'var(--green-dim)';
    badge.style.color = 'var(--green)';
  } else {
    badge.style.borderColor = 'var(--yellow)';
    badge.style.background = 'var(--yellow-dim)';
    badge.style.color = 'var(--yellow)';
  }
}

function updatePortfolioSummary(report) {
  const conf = document.getElementById('portfolio-confidence');
  if (conf) conf.textContent = (report.confidence_pct || 62) + '%';
}

// ── UTILS ────────────────────────────────────────────────────
function showLoading(show) {
  const el = document.getElementById('loading-indicator');
  if (el) el.style.display = show ? 'flex' : 'none';
}

function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}

function togglePortfolio() {
  const w = document.getElementById('port-wrapper');
  const b = document.getElementById('port-btn');
  if (!w) return;
  const isVisible = w.style.maxHeight !== '0px' && w.style.maxHeight !== '';
  if (isVisible) {
    w.style.maxHeight = '0';
    w.style.opacity = '0';
    if (b) b.classList.remove('on');
  } else {
    w.style.maxHeight = '160px';
    w.style.opacity = '1';
    if (b) b.classList.add('on');
  }
}

function toggleNews() {
  const p = document.getElementById('news-panel');
  const b = document.getElementById('news-btn');
  if (!p) return;
  const open = p.classList.toggle('open');
  if (b) {
    b.classList.toggle('open', open);
    b.textContent = open ? '▲ Ocultar Noticias' : '▼ Ver Noticias';
  }
}

function setView(v) {
  const isExt = v === 'extended';
  document.querySelectorAll('.extended-only').forEach(el => el.classList.toggle('visible', isExt));
  const sb = document.getElementById('view-short-btn');
  const eb = document.getElementById('view-ext-btn');
  if (sb) sb.classList.toggle('on', v === 'short');
  if (eb) eb.classList.toggle('on', v === 'extended');
}

function showTab(name, el) {
  document.querySelectorAll('.page').forEach(x => x.classList.remove('visible'));
  document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
  const page = document.getElementById('tab-' + name);
  if (page) page.classList.add('visible');
  if (el) el.classList.add('active');

  // Load data for the tab
  if (name === 'entries') renderEntries();
  if (name === 'history') loadTradingDays();
}

// Start
document.addEventListener('DOMContentLoaded', initDashboard);
